# Superheroes Carousel with reflections using sibling-index() and sibling-count()

A Pen created on CodePen.

Original URL: [https://codepen.io/cbolson/pen/OPyvEaE](https://codepen.io/cbolson/pen/OPyvEaE).

Using sibling-count() and sibling-index() to define total number of elements and get the index of each element.
Based on this previous pen https://codepen.io/cbolson/pen/wBBozqx