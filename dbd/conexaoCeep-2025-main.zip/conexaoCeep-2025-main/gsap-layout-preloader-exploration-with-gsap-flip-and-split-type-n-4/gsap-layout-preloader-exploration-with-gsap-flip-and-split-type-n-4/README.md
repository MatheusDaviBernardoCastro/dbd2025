# [gsap] ❍ Layout Preloader Exploration with GSAP, FLIP and SPLIT TYPE N°4

A Pen created on CodePen.

Original URL: [https://codepen.io/filipz/pen/wBvVKZj](https://codepen.io/filipz/pen/wBvVKZj).

