# Product Slider - Marvel Characters

A Pen created on CodePen.

Original URL: [https://codepen.io/leonam-silva-de-souza/pen/MYgQpxp](https://codepen.io/leonam-silva-de-souza/pen/MYgQpxp).

Source: Going-to Internet (https://www.youtube.com/watch?v=drOgpionKpY)