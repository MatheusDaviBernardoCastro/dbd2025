# Vue.js ( Responsive Shuffle Image Gallery )

A Pen created on CodePen.

Original URL: [https://codepen.io/noirsociety/pen/YPyNOjP](https://codepen.io/noirsociety/pen/YPyNOjP).

