# Gradient Glow Cards

A Pen created on CodePen.

Original URL: [https://codepen.io/thebabydino/pen/jENvVvg](https://codepen.io/thebabydino/pen/jENvVvg).

Changes:

* no extra element needed for the semi-transparent dark cover - using a `padding-box`-restricted background layer on top of the `border-box` covering gradient

* this gradient is inherited as a custom property onto an absolutely positioned pseudo which then gets blurred to create the glow

* the stop lists are also custom properties in order to make it easier to switch between cards

---

If the work I've been putting out since early 2012 has helped you in any way or you just like it, then please remember that praise doesn't keep me afloat financially... but you can! So please consider supporting my work in one of the following ways:

* being a cool cat 😼🎩 and supporting it monthly on Ko-fi or via a one time donation

[![ko-fi](https://assets.codepen.io/2017/btn_kofi.svg)](https://ko-fi.com/anatudor)

* making a weekly anonymous donation via Liberapay - I'll never know who you are if that's your wish

[![Liberapay](https://assets.codepen.io/2017/btn_liberapay.svg)](https://liberapay.com/anatudor/)

* getting me a chocolate voucher

[![Zotter chocolate](https://assets.codepen.io/2017/zotter.jpg)](https://www.zotter.at/en/online-shop/gifts/gift-vouchers/choco-voucher)

* if you're from outside Europe, becoming a patron on Patreon (don't use it for one time donations or if you're from Europe, we're both getting ripped off)

[![become a patron button](https://assets.codepen.io/2017/btn_patreon.png)](https://www.patreon.com/anatudor)

* or at least sharing this to show the world what can be done with CSS these days

Thank you!