# Pulsing Star Disintegration

A Pen created on CodePen.

Original URL: [https://codepen.io/VoXelo/pen/raOvrLO](https://codepen.io/VoXelo/pen/raOvrLO).

Interactive Three.js scene where a star shape breaks apart into particles and reassembles, enhanced by pulse waves, bloom, and dynamic color themes.