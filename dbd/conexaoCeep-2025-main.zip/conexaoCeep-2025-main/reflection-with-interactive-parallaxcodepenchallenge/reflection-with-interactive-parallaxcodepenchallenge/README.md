# Reflection with Interactive Parallax - CodePenChallenge

A Pen created on CodePen.

Original URL: [https://codepen.io/jerora98/pen/gbavKaX](https://codepen.io/jerora98/pen/gbavKaX).

A sleek, modern product showcase featuring a luminous, neon-framed box and its soft, blurred reflection below. Hovering or moving the mouse subtly tilts the view for an interactive parallax effect. Built with CSS gradients, mask blending, and a light touch of JavaScript for dynamic movement.