document.addEventListener("mousemove", (e) => {
	const container = document.querySelector(".reflection-container");
	const x = e.clientX / window.innerWidth;
	const y = e.clientY / window.innerHeight;
	container.style.transform = `perspective(1000px) rotateX(${
		(y - 0.5) * 5
	}deg) rotateY(${(x - 0.5) * 5}deg)`;
});
