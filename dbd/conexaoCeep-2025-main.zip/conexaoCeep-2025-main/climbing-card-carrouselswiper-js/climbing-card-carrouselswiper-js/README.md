# Climbing Card Carrousel - Swiper JS

A Pen created on CodePen.

Original URL: [https://codepen.io/josetxu/pen/wBBqaer](https://codepen.io/josetxu/pen/wBBqaer).

https://swiperjs.com/demos#effect-coverflow