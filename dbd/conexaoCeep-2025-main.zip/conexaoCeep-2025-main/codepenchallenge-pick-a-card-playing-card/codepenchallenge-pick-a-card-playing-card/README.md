# #CodePenChallenge: Pick a Card | Playing Card

A Pen created on CodePen.

Original URL: [https://codepen.io/HejChristian/pen/RNwXexO](https://codepen.io/HejChristian/pen/RNwXexO).

My first CodePen challenge 🥳 

I went with the image card for this one, and thought up how an interactive playing card might look, feel, and animate. I've been playing plenty of board games recently so that very much inspired this approach.