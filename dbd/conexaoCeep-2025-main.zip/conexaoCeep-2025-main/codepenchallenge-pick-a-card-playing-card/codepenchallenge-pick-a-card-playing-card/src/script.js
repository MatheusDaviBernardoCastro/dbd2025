// Grab the svg path lengths, so we can animate them easily.
// These -could- be set directly into the CSS if you knew the values before hand, making this a CSS-only friendly approach to SVG animation 

// Ability Hatch
const abilityHatch = document.querySelector('#ability-hatch-crack');
abilityHatch.style.strokeDasharray = abilityHatch.getTotalLength();
abilityHatch.style.strokeDashoffset = abilityHatch.getTotalLength();
// console.log(`Study Path = ${abilityHatch.getTotalLength()}`);

// Helps dismiss the dialog/sidebar, allowing folks to click anywhere
experimentDialog.addEventListener('click', ({target:dialog}) => {
  if (dialog.nodeName === 'DIALOG') {
    dialog.close('dismiss');
  }
});