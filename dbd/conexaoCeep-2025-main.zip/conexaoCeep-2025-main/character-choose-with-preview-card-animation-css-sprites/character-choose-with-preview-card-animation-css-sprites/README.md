# Character choose with preview card animation (CSS sprites)

A Pen created on CodePen.

Original URL: [https://codepen.io/Maseone/pen/dPPPXQL](https://codepen.io/Maseone/pen/dPPPXQL).

A pure CSS character selector featuring a list of characters on the left and a live animated preview on the right. The animations are driven entirely by sprite sheets, with hover effects and adjustable frame rates. The preview also displays the current row and column of the sprite sheet in real time. Designed to work in modern browsers (Chrome 134+).