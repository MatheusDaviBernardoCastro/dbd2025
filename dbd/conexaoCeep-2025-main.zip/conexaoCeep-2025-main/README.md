# conexaoCeep-2025
Atividade de amostra científica do Centro Estadual de Educação Profissional de Cianorte - 2°E

04/08/2025 - criação dos arquivos iniciais
