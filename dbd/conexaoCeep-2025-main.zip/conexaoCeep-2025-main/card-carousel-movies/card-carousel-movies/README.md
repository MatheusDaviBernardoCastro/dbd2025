# Card Carousel (Movies)

A Pen created on CodePen.

Original URL: [https://codepen.io/wpmad/pen/GggrmvY](https://codepen.io/wpmad/pen/GggrmvY).

