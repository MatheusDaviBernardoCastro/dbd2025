import zim from "https://zimjs.org/cdn/017/zim";

// see https://zimjs.com
// and https://zimjs.com/learn
// and https://zimjs.com/docs

const covers = ["build.jpg", "castle.jpg", "ganymede.jpg", "lastyear.jpg", "martian.jpg", "maze.jpg", "time.jpg", "titan.jpg", "ubik.jpg"];
const path = "https://assets.codepen.io/2104200/";

new Frame(FIT, 800, 800, darker, dark, ready, covers, path, new ProgressBar());
function ready() {

	// given F (Frame), S (Stage), W (width), H (height)
    // put your code here

	loop(covers, (cover,i)=>{
		covers[i] = new Pic(cover).reg(CENTER);
	});
	
	// This is going in ZIM 018 - we were just working on it when the challenge came out!
	// UPDATE: this code has now been brought into ZIM - see https://zimjs.com/018.html
	// where it is called Carousel3D
	
	zim.Dex = function(width, height, pages, widthFactor, heightFactor, curve, interactive, continuous, fade, fadeColor, sensitivity, swiperType, min, max, damp, factor) {

		// this is not really finished - just hard coded...
		
		var interactive = false;
		var fade = .07;
		var fadeColor = zdf.color;		

		var continuous = true;
		var min = null;
		var max = null;
		var sensitivity = .3
		var swiperType = null;
		var damp = M?.5:null;
		var factor = 1;
		var wrapGo = false;
			

		this.zimContainer_constructor(width,height);
		var that = this;
		this.type = "Dex";
		
		that.curve = curve;

		that.backing = new zim.Rectangle(width, height, clear).addTo(this).expand();
	
		that.holder = new zim.Container(width, height).addTo(this);
		var center = width/2;
		var r = height/2;
		var shift = height/pages.length;
		zim.loop(pages, function(page, i) {
			page.dexIndex = i;
			page.center(that.holder)
			if (i!=0 || !interactive) {
				page.mouseEnabled = false;
				page.mouseChildren = false;
			}
			page.startX = page.x;	
			page.shiftX = i*shift;	
			if (fade) page.fader = new zim.Rectangle(page.width, page.height, fadeColor, page.backing?page.backing.borderColor:null, page.backing?page.backing.borderWidth:null, page.backing?page.backing.corner:null).addTo(page).noMouse();
		})

		if (!continuous) {
			min = -(pages.length-1)*shift;
			max = 0;
		} 
		
		that.amount = 0;

		that.index = null;
		that.down = false;
		that.waiting = false;
		that.added(function(){
			that.swiper = new zim.Swiper(that.backing, that, "amount", sensitivity, swiperType, min, max, damp, null, factor);	
			that.swiper.on("swipedown", function() {
				that.down = true;
			})
			that.swiper.on("swipeup", function(){
				that.down = false;	
				that.waiting = true;
			})		
			that.tick = Ticker.add(()=>{
				that.holder.loop(function(page, i) {					
					page.x = page.startX - r + (that.amount+r+r*2*1000000 + page.shiftX) % (r*2);
					var delta = page.x - center;
					var h = Math.sqrt(Math.pow(r,2) - Math.pow(delta,2)) * 2;				
					page.height = h;
					var sh = zim.sign((width/2-page.x)) * Math.round(Math.pow((width/2-page.x), 2)/(20+800*(1-that.curve)));
					page.mov(delta*widthFactor+sh);
					page.height = constrain(page.height - (height-page.height)*heightFactor,0,100000);
								
				})				
				that.holder.sortBy("height");
				that.currentPage = that.holder.getChildAt(that.holder.numChildren-1);				
				var index = that.currentPage.dexIndex;
				if (index != that.index) {
					that.holder.loop(function(page,i,t) {	
						if (interactive) {					
							if (page==that.currentPage) { 
								page.mouseEnabled = true;
								page.mouseChildren = true;
							} else {
								page.mouseEnabled = false;
								page.mouseChildren = false;
							}
						}
						if (fade) {
							// page.backing.color = page.colorO.toColor(fadeColor, fade*(t-i-1));
							// put a rectangle over item - in item - rather than change above
							page.fader.alpha = fade*(t-i-1);
							// if (page.backing) page.backing.borderColor = dark.toColor(fadeColor, fade*(t-i-1));
						}
					});
					that.index = index;
					that.dispatchEvent("change");
				}
				// that.swiper.desiredValue-=.5 // animates
				if (that.down==false) {
					if (that.waiting && Math.abs(that.amount-that.swiper.desiredValue) < shift/10) {
						that.swiper.desiredValue = Math.round(that.amount/shift)*shift;
						that.waiting = false;
					}
				}
				if (!continuous) {
					that.holder.loop(function(page) {
						if (page.dexIndex < index && page.x > center) page.visible = false;
						else if (page.dexIndex > index && page.x < center) page.visible = false;
						else page.visible = true;
					})
				} 
			});
			
		});		

		this.next = function() {
			var newVal = that.swiper.desiredValue-shift;
			if (!continuous && newVal < min) return that;
			that.swiper.desiredValue = newVal;
			return that;
		}
		this.prev = function() {
			var newVal = that.swiper.desiredValue+shift;
			if (!continuous && newVal > max) return that;
			that.swiper.desiredValue = newVal;
			return that;
		}
		this.go = function(target) {
			var num;
			var index = that.index;
			if (typeof target == "number") {
				num = target;				
			} else {
				num = target.dexIndex;
			}
			if (num == index) return that;
			if (!continuous) {
				that.swiper.desiredValue = -num*shift;
			} else {
				if (wrapGo) {
					var a;
					var b;
					if (num>index) {
						a = index+pages.length - num;
						b = num-index;
						if (b > a) {
							that.swiper.desiredValue += a*shift;
						} else {
							that.swiper.desiredValue -= b*shift;
						}
					} else {
						a = num+pages.length - index;
						b = index-num;
						if (b > a) {
							that.swiper.desiredValue -= a*shift;
						} else {
							that.swiper.desiredValue += b*shift;
						}
					}
				} else {
					if (num>index) that.swiper.desiredValue -= (num-index)*shift;
					else that.swiper.desiredValue += (index-num)*shift;
				}
			}
		}
	}
	zim.extend(zim.Dex, zim.Container, null, "zimContainer");

	const indicator = new Indicator({
		width:covers.length*20,
		height:25,
		num:covers.length,
		interactive:true,
		toggleFirst:false,
		delayLights:true
	}).pos(0,80,CENTER,BOTTOM).change(()=>{
		dex.go(indicator.index);
	})
	const dex = new zim.Dex(800,500,covers,1,3,.5).center().change(()=>{
		indicator.index = dex.index;
	});

	new Arrow().pos(50,0,RIGHT,CENTER).tap(()=>{
		dex.next();
	});
	new Arrow().rot(180).pos(50,0,LEFT,CENTER).tap(()=>{
		dex.prev();
	});
	
	
	F.madeWith({box:darker}).pos(40,40,RIGHT,BOTTOM);
	
} // end ready

// ~~~~~~~~~~~~~~~~~~~~~
// If you see this... 
// join us at https://zimjs.com/forum
// ZIM leads to a wonderful life - trust us!
// ~~~~~~~~~~~~~~~~~~~~~
