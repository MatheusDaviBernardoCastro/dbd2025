# Card Carousel with ZIM for CodePen Challenge

A Pen created on CodePen.

Original URL: [https://codepen.io/zimjs/pen/azzVprZ](https://codepen.io/zimjs/pen/azzVprZ).

Preparing for ZIM 018 with a Dex class to make a scrolling carousel - we already have Carousel() so leaving that as it is.  We still need to fix this up a bit so it is easier to spread out properly.

ZIM provides JavaScript conveniences, components and controls for the Canvas. Code Creativity with ZIM!  See the CodePen Topic page for ZIM at https://codepen.io/topic/zim


