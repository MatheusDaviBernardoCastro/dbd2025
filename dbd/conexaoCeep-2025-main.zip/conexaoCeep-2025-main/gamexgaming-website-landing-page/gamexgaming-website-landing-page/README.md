# GameX - Gaming Website Landing Page

A Pen created on CodePen.

Original URL: [https://codepen.io/leonam-silva-de-souza/pen/MYgLgvV](https://codepen.io/leonam-silva-de-souza/pen/MYgLgvV).

Source: codewithsadee (https://www.youtube.com/watch?v=BK9_voy6VXU)