# Yu-Gi-Oh Cards Reveal

A Pen created on CodePen.

Original URL: [https://codepen.io/Alansdead/pen/zxxpzbO](https://codepen.io/Alansdead/pen/zxxpzbO).

