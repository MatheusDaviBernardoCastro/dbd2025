# [cpc] Pokemon Slide Gallery (yet another circle gallery)

A Pen created on CodePen.

Original URL: [https://codepen.io/cbolson/pen/raBJWOJ](https://codepen.io/cbolson/pen/raBJWOJ).

Yet another circular gallery.
This one was for a CodePen challenge.

I initially based the code on this previous pen https://codepen.io/cbolson/pen/vEBWwxL however I ended up refactoring most of it as usual.