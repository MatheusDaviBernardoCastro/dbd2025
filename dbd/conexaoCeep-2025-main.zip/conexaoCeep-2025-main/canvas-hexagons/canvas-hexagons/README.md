# Canvas Hexagons

A Pen created on CodePen.

Original URL: [https://codepen.io/creativeocean/pen/yyYqWNb](https://codepen.io/creativeocean/pen/yyYqWNb).

